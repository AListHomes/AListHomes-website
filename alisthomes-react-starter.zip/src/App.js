
import React from 'react';

function App() {
  return (
    <div style={{ textAlign: 'center', marginTop: '5rem' }}>
      <h1>Welcome to A List Homes</h1>
      <p>This is your custom real estate website starter!</p>
    </div>
  );
}

export default App;
